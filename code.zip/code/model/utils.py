﻿# -*- coding: utf-8 -*-
"""
The utils inclues the assistant funcitons
to simplify the model file and add tensors tensorboard.
"""
import re
import traceback
from tensorflow.contrib.layers.python.layers import initializers
import tensorflow as tf
from tensorflow.contrib import layers
from tensorflow.contrib.framework.python.ops import arg_scope
from tensorflow.contrib.layers.python.layers import layers
from tensorflow.contrib.layers.python.layers import regularizers
from tensorflow.python.ops import init_ops
from tensorflow.python.ops import math_ops
import numpy as np

def getActivationFunctionOp(act_name="relu"):
    if type(act_name) != str and type(act_name) != unicode:
        return act_name
    if act_name.lower() == 'relu':
        return tf.nn.relu
    elif act_name.lower() == 'tanh':
        return tf.nn.tanh
    elif act_name.lower() == 'lrelu':
        return lambda x: tf.nn.leaky_relu(x, alpha=0.01)
    elif act_name.lower() == 'llrelu':
        return lambda x: tf.nn.leaky_relu(x, alpha=0.1)
    elif act_name.lower() == 'prelu':
        return lambda x: parametric_relu(x)
    else:
        return tf.nn.relu

def parametric_relu(_x):
    alphas = tf.get_variable('alpha', _x.get_shape()[-1],
                             initializer=tf.constant_initializer(0.0),
                             dtype=tf.float32)
    from tensorflow.contrib.layers.python.layers.layers import _add_variable_to_collections
    from tensorflow.python.framework import ops
    _add_variable_to_collections(alphas, [ops.GraphKeys.MODEL_VARIABLES], None)
    pos = tf.nn.relu(_x)
    neg = alphas * (_x - abs(_x)) * 0.5

    return pos + neg

def combine_parted_variables(vs, combine_postfix='/combine'):
    mmap = {}
    for x in vs:
        mkey = re.sub('/part_[0-9]*:', '/', x.name)
        if mkey in mmap:
            mmap[mkey].append(x)
        else:
            mmap[mkey] = [x]
    return [tf.concat(t, 0, name=k.replace(':', '_') + combine_postfix) for k, t in mmap.items()]

def add_embed_layer_norm(layer_tensor, columns, model_name=""):
  monitor_dict = {}
  if layer_tensor is None:
    return
  i = 0
  for column in sorted(set(columns), key=lambda x: x.key):
    try:
      dim = column.dimension
    except:
      dim = column.embedding_dimension
    tf.summary.scalar(name=column.name, tensor=tf.reduce_mean(tf.norm(layer_tensor[:, i:i + dim], axis=-1)))
    monitor_dict[model_name+"."+column.name] = tf.reduce_mean(tf.norm(layer_tensor[:, i:i + dim], axis=-1))
    i += dim
  return monitor_dict

def add_embed_layer_norm_batch(layer_tensor, columns, model_name=""):
  monitor_dict = {}
  if layer_tensor is None:
    return
  i = 0
  for column in sorted(set(columns), key=lambda x: x.key):
    try:
      dim = column.dimension
    except:
      dim = column.embedding_dimension
    monitor_dict[model_name+"."+column.name] = tf.norm(layer_tensor[:, i:i + dim], axis=-1)
    i += dim
  return monitor_dict

def add_norm2_summary(collection_name, summary_prefix="Norm2/", contain_string="", model_name=None):
  monitor_dict = {}
  variables = tf.get_collection(collection_name)
  vv = combine_parted_variables(variables)
  for x in vv:
    if contain_string in x.name:
      print("add norm2 %s to summary with shape %s" % (str(x.name), str(x.shape)))
      try:
        tf.summary.scalar(name=summary_prefix + x.name.replace(":", "_"), tensor=tf.norm(x))
        monitor_dict[model_name + "." + x.name.replace(":", ".")] = tf.norm(x)
      except:
        tf.summary.scalar(name=summary_prefix + x.name.replace(":", "_"), tensor=tf.norm(x, axis=[-2, -1]))
        monitor_dict[model_name + "." + x.name.replace(":", ".")] = tf.norm(x, axis=[-2, -1])
  return monitor_dict

def add_weight_summary(collection_name, summary_prefix="Weight/", contain_string="", model_name=""):
  monitor_dict = {}
  variables = tf.get_collection(collection_name)
  vv = combine_parted_variables(variables)
  for x in vv:
    if contain_string in x.name:
      try:
        name = x.name.replace(":", "_")
        x = tf.reshape(x, [-1])
        print("add weight %s to summary with shape %s" % (str(x.name), str(x.shape)))

        tf.summary.scalar(name=summary_prefix + "Norm2/" + name,
                          tensor=tf.norm(x, axis=-1))
        monitor_dict[model_name + "." + "Weight.Norm2." + name.replace("/", ".")] = tf.norm(x, axis=-1)
        tf.summary.histogram(name=summary_prefix + "Hist/" + name,
                             values=x)
        mean, variance = tf.nn.moments(x, axes=0)
        tf.summary.scalar(name=summary_prefix + "Mean/" + name,
                          tensor=mean)
        monitor_dict[model_name+"."+"Weight.Mean." + name.replace("/", ".")] = mean
        tf.summary.scalar(name=summary_prefix + "Variance/" + name,
                          tensor=variance)
        tf.summary.scalar(name=summary_prefix + "PosRatio/" + name, tensor=greater_zero_fraction(x))
        monitor_dict[model_name+"."+"PosRatio." + name.replace("/", ".")] = greater_zero_fraction(x)
      except Exception as e:
        print('Got exception run : %s | %s' % (e, traceback.format_exc()))
        print("add_dense_output_summary with rank not 2: [%s],shape=[%s]" % (str(x.name), str(x.shape)))
  return monitor_dict

def add_dense_output_summary(collection_name, summary_prefix="DenseOutput/", contain_string="", model_name=""):
  monitor_dict = {}
  variables = tf.get_collection(collection_name)
  for x in variables:
    if contain_string in x.name:
      try:
        print("add dense_output %s to summary with shape %s" % (str(x.name), str(x.shape)))
        if len(x.shape) == 3:
          tf.summary.scalar(name=summary_prefix + "Norm2/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(tf.norm(x)))
          tf.summary.histogram(name=summary_prefix + "AbsHistMax/" + x.name.replace(":", "_"),
                               values=tf.reduce_max(tf.abs(x), axis=-1))
          mean, variance = tf.nn.moments(x, axes=[0, 1])
          tf.summary.scalar(name=summary_prefix + "Mean/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(mean))
          tf.summary.scalar(name=summary_prefix + "Variance/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(variance))
          tf.summary.histogram(name=summary_prefix + "PosR/" + x.name.replace(":", "_"),
                               values=greater_zero_histogram(x))
          monitor_dict[model_name+"."+"Norm2." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(tf.norm(x))
          monitor_dict[model_name+"."+"Variance." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(variance)
          monitor_dict[model_name+"."+"Mean." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(mean)
        elif x.shape[1] > 1:
          tf.summary.scalar(name=summary_prefix + "Norm2/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(tf.norm(x, axis=-1)))
          tf.summary.histogram(name=summary_prefix + "AbsHistMax/" + x.name.replace(":", "_"),
                               values=tf.reduce_max(tf.abs(x), axis=-1))
          mean, variance = tf.nn.moments(x, axes=-1)
          tf.summary.scalar(name=summary_prefix + "Mean/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(mean))
          tf.summary.scalar(name=summary_prefix + "Variance/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(variance))
          tf.summary.histogram(name=summary_prefix + "PosR/" + x.name.replace(":", "_"),
                               values=greater_zero_histogram(x))
          monitor_dict[model_name+"."+"Norm2." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(tf.norm(x))
          monitor_dict[model_name+"."+"Variance." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(variance)
          monitor_dict[model_name+"."+"Mean." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(mean)
        else:
          tf.summary.scalar(name=summary_prefix + "Norm2/" + x.name.replace(":", "_"),
                            tensor=tf.reduce_mean(tf.norm(x, axis=-1)))
          tf.summary.histogram(name=summary_prefix + "AbsHistMax/" + x.name.replace(":", "_"),
                               values=tf.reduce_max(tf.abs(x)))
          mean, variance = tf.nn.moments(x, axes=0)
          tf.summary.scalar(name=summary_prefix + "Mean/" + x.name.replace(":", "_"),
                            tensor=mean[0])
          tf.summary.scalar(name=summary_prefix + "Variance/" + x.name.replace(":", "_"),
                            tensor=variance[0])
          monitor_dict[model_name+"."+"Norm2." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(tf.norm(x))
          monitor_dict[model_name+"."+"Variance." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(variance)
          monitor_dict[model_name+"."+"Mean." + x.name.replace(":", "_").replace("/", ".")] = tf.reduce_mean(mean)
        tf.summary.scalar(name=summary_prefix + "PosRatio/" + x.name.replace(":", "_"), tensor=greater_zero_fraction(x))
      except Exception as e:
        print('Got exception run : %s | %s' % (e, traceback.format_exc()))
        print("add_dense_output_summary with rank not 2: [%s],shape=[%s]" % (str(x.name), str(x.shape)))
  return monitor_dict

# overall fraction
def greater_zero_fraction(value, name=None):
    with tf.name_scope(name, "greater_fraction", [value]):
        value = tf.convert_to_tensor(value, name="value")
        zero = tf.constant(0, dtype=value.dtype, name="zero")
        return math_ops.reduce_mean(
            math_ops.cast(math_ops.greater(value, zero), tf.float32))

# histogram of each sample's zero fraction
def greater_zero_histogram(value, name=None):
    with tf.name_scope(name, "greater_histogram", [value]):
        value = tf.convert_to_tensor(value, name="value")
        zero = tf.constant(0, dtype=value.dtype, name="zero")
        return math_ops.reduce_mean(
            math_ops.cast(math_ops.greater(value, zero), tf.float32), axis=-1)

def add_layer_summary(value, tag):
    tf.summary.scalar("%s/fraction_of_zero_values" % tag, tf.nn.zero_fraction(value))
    tf.summary.histogram("%s/activation" % tag, value)

def add_logits_summary(name, tensor):
    monitor_dict = {}
    tf.summary.scalar("%s/scalar/mean" % name, tf.reduce_mean(tensor))
    tf.summary.scalar("%s/scalar/max" % name, tf.reduce_max(tensor))
    tf.summary.scalar("%s/scalar/min" % name, tf.reduce_min(tensor))
    monitor_dict["%s/scalar/mean" % name] = tf.reduce_mean(tensor)
    monitor_dict["%s/scalar/max" % name] = tf.reduce_max(tensor)
    monitor_dict["%s/scalar/min" % name] = tf.reduce_min(tensor)
    tf.summary.histogram("%s/histogram" % name, tensor)
    return monitor_dict

def model_arg_scope(weight_decay=0.0005, weights_initializer=initializers.xavier_initializer(),
                    biases_initializer=init_ops.zeros_initializer()):
  with arg_scope(
      [layers.fully_connected, layers.conv2d],
      weights_initializer=weights_initializer,
      weights_regularizer=regularizers.l2_regularizer(weight_decay),
      biases_initializer=init_ops.zeros_initializer()) as arg_sc:
    return arg_sc

def seq_featuer_maker(features,feature_columns,fg,seq_name,seq_length_name,scope):
    seq_columns= feature_columns.get(seq_name,None)
    seq_max_length = fg.get_seq_len_by_sequence_name(seq_name)
    seq_features = layers.input_from_feature_columns(features, seq_columns, scope=scope) # [bs*seq_len, dim] bs个样本的内的第1个序列元素，bs个样本的内的第2个序列元素，。。。。
    seq_sequence_split = tf.split(seq_features,seq_max_length,axis=0)  #[ [bs, dim] ] list 形式，list size = seq_len 不是tensor,list内第n个元素表示bs个序列第n个元素embedding
    seq_sequence_stack = tf.stack(values=seq_sequence_split, axis=1)  # [batch,seq_len,dim]
    seq_feature_2d = tf.reshape(seq_sequence_stack,[-1, tf.shape(seq_sequence_stack)[2]])  # [bs*len,dim]

    seq_length_columns = feature_columns.get(seq_length_name,None)
    seq_length_features = layers.input_from_feature_columns(features, seq_length_columns, scope=scope)  # [bs,1]
    sequence_mask = tf.sequence_mask(tf.reshape(seq_length_features, [-1]),seq_max_length)  # [bs,seq_max_len],bool 根据长度来生产mask的sequence
    masked_seq_features = tf.reshape(tf.where(tf.reshape(sequence_mask, [-1]), seq_feature_2d,tf.zeros_like(seq_feature_2d)), tf.shape(seq_sequence_stack)) #[batch,seq_len,dim]
    return masked_seq_features,seq_length_features,seq_max_length

def fft(input_seq, F_real, F_imag, name):
        # input_seq:    input seq feature ,[batch,seq_len]
        # F        :    fft_transfer_maxtrix, [seq_len,seq_len]
        # name     : the operation name
        freq_signal_real = tf.matmul(input_seq,F_real)
        freq_signal_imag = tf.matmul(input_seq, F_imag)
        amplitude = tf.sqrt(tf.square(freq_signal_real) + tf.square(freq_signal_imag))
        phase = tf.atan(freq_signal_real / (freq_signal_imag + 1e-8))
        return freq_signal_real, freq_signal_imag,amplitude,phase

def get_fft_transfer_matrix(N):
        # N:seq length
        w = np.true_divide(-2j * np.pi, N)
        row = np.reshape(np.arange(0, N, 1), [N, 1])
        column = np.reshape(np.arange(0, N, 1), [1, N])
        exper_matrix = w * np.matmul(row, column)
        F = np.exp(exper_matrix)
        F_real =  np.real(F)
        F_imag = np.imag(F)
        tensor_F = tf.constant(F, dtype=tf.complex64,name="FFT_Matrix")
        tensor_F_real = tf.constant(F_real, dtype=tf.float32, name="FFT_Matrix_real")
        tensor_F_imag = tf.constant(F_imag, dtype=tf.float32, name="FFT_Matrix_imag")
        return tensor_F,tensor_F_real,tensor_F_imag

def model_arg_scope(weight_decay=0.0005, weights_initializer=initializers.xavier_initializer(),
                    biases_initializer=init_ops.zeros_initializer()):
  with arg_scope(
      [layers.fully_connected, layers.conv2d],
      weights_initializer=weights_initializer,
      weights_regularizer=regularizers.l2_regularizer(weight_decay),
      biases_initializer=biases_initializer) as arg_sc:
    return arg_sc