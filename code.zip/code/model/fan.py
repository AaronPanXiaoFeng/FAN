#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @File  : deeprerank.py
# @Author: hongming
# @Date  : 2021/5/11

import tensorflow as tf
import traceback
from tensorflow.python.ops import array_ops
from fg import FgParser
from prada_interface.algorithm import Algorithm
from tensorflow.python.ops import partitioned_variables
from tensorflow.contrib import layers
from tensorflow.python.training import training_util
from tensorflow.python.framework import ops
from optimizer import optimizer_ops as myopt
from tensorflow.python.ops import control_flow_ops
from tensorflow.python.ops import state_ops
from optimizer.adagrad_decay import SearchAdagradDecay
from optimizer.adagrad import SearchAdagrad
from optimizer.gradient_decent import SearchGradientDecent
from tensorflow.python.ops import metrics
from prada_model_ops.metrics import auc
from tensorflow.contrib.framework.python.ops import arg_scope
import numpy as np
from tensorflow.python.framework.errors_impl import OutOfRangeError, ResourceExhaustedError
from requests.exceptions import ConnectionError
from attention import attention as atten_func
from utils import model_arg_scope
from utils import fft
from utils import get_fft_transfer_matrix

class FAN(Algorithm):

    def init(self,context):

        # config initialization
        self.context=context
        self.logger=self.context.get_logger()
        self.logger.info("FAN Init!")
        self.config = self.context.get_config() # all config.json in self.config
        self.model_conf = self.config.get_model_config()  #algo_conf.json
        self.fg = FgParser(self.config.get_fg_config())  #fg.json
        self.model_ops = context.get_model_ops()
        self.name="deepctr"

        self.metrics = {}


        #optimizer config
        for (k, v) in self.config.get_all_algo_config().items():
            self.model_name = k
            self.algo_config = v
            self.opts_conf = v['optimizer']
            self.model_conf = v['modelx']

        self.variable_partitioner = partitioned_variables.min_max_variable_partitioner(
            max_partitions=self.config.get_job_config("ps_num"),
            min_slice_size=self.config.get_job_config("embedding_min_slice_size"))
        try:
            self.is_training = tf.get_default_graph().get_tensor_by_name("training:0")
        except KeyError:
            self.is_training = tf.placeholder(tf.bool, name="training")

        # block settings
        self.regularizerl2 = layers.l2_regularizer(self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])
        self.regularizerl1 = layers.l1_regularizer(self.model_conf["model_hyperparameter"]["regularizer_weight_l1"])
        self.need_dropout = self.model_conf["model_hyperparameter"]["need_dropout"]
        self.dropout_rate = self.model_conf["model_hyperparameter"]["dropout_rate"]
        self.gate_hidden_dims = self.model_conf["model_hyperparameter"]["gate_hidden_units"]
        self.ctr_expert_main_hidden_dims = self.model_conf["model_hyperparameter"]["ctr_expert_main_hidden_dims"]
        self.ctr_expert_bias_hidden_dims = self.model_conf["model_hyperparameter"]["ctr_expert_bias_hidden_dims"]
        self.negative_net_hidden_dims = self.model_conf["model_hyperparameter"]["negative_net_hidden_dims"]
        self.faituage_net_hidden_dims = self.model_conf["model_hyperparameter"]["faituage_net_hidden_dims"]


        self.loss_weights = self.model_conf["model_hyperparameter"]["loss_parts_weight"]
        self.need_batchnorm =self.model_conf['model_hyperparameter']['batch_norm']

    def inference(self, features, feature_columns):
        # split input features
        self.features = features
        self.clk_label = features.get("clk_label", None)
        self.fatigue_label = features.get("fatigue_label",None)
        self.cate_expo_num = features.get("cate_expo_7d",None)
        self.input_layer(features,feature_columns)
        uin_vector = self.UIN("UIN")
        fan_vector = self.FRM("FAN", self.user_cate_pv_fatigue_features,self.cate_fatigue_feature,self.gate_features)
        ctr_logits,fatigue_logits = self.fusion_net("fusion",uin_vector,fan_vector)
        return ctr_logits,fatigue_logits

    def build_graph(self, context, features, feature_columns, labels):
        # set global step as 0
        self.global_step=self.set_global_step()
       # inference
        self.ctr_logits,self.fatigue_logits = self.inference(features, feature_columns) #[b,1]
        self.loss_op=self.loss(self.ctr_logits,self.fatigue_logits,labels)
        #optimizer
        self.train_ops=self.optimizer(context,self.loss_op)
        #prediction
        self.ctr_prediction,self.fatigue_prediction = self.predictions(self.ctr_logits,self.fatigue_logits)

        self.mark_output(self.ctr_prediction,self.fatigue_prediction)

        self.summary()
        self.add_worker_summary_hook(context)

        self.reset_auc_ops, self.localvar=self.set_reset_op()

    def loss(self,logits,fatigue_value, labels):
        #return self.loss_ctr_cvr_auc(logits, labels)
        return self.double_loss(logits,fatigue_value,labels)

    def double_loss(self,logits,fatigue_value,labels):
        with self.variable_scope("{}_Loss_Op".format(self.model_name)):
            # reg loss
            self.reg_loss = tf.reduce_sum(tf.get_collection(tf.GraphKeys.REGULARIZATION_LOSSES))
            # ctr_loss
            self.ctr_label = tf.reshape(self.clk_label,shape=tf.shape(logits))
            self.ctr_loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(logits=logits, labels=self.ctr_label))
            # fatigue_loss
            fatigue_mask = tf.where(tf.greater(self.cate_expo_num, tf.fill(tf.shape(self.cate_expo_num), 3.0)),
                                             tf.fill(tf.shape(self.cate_expo_num), True),
                                              tf.fill(tf.shape(self.cate_expo_num), False))
            self.masked_fatigue_label = tf.boolean_mask(self.fatigue_label,fatigue_mask)
            self.masked_fatigue_value = tf.boolean_mask(fatigue_value,fatigue_mask)
            self.masked_fatigue_prediction = tf.nn.sigmoid(self.masked_fatigue_value)
            self.fatigue_loss = tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(logits=self.masked_fatigue_value,labels=self.masked_fatigue_label))

            ctrloss_weight = self.loss_weights.get("ctr", 1.0)
            regloss_weight = self.loss_weights.get("reg", 0.1)
            fatigue_weight_start = self.loss_weights.get("fatigue_weight_start", 0.1)
            fatigue_weight_end = self.loss_weights.get("fatigue_weight_end", 0.5)
            fatigue_weight_max_step = self.loss_weights.get("fatigue_weight_max_step", 1e6)
            fatigue_weight = (fatigue_weight_end-fatigue_weight_start)/fatigue_weight_max_step*self.global_step+fatigue_weight_start
            total_loss = ctrloss_weight * self.ctr_loss + regloss_weight * self.reg_loss + fatigue_weight * self.fatigue_loss
        return total_loss

    def run_train(self, context, mon_session, task_index, thread_index):
        localcnt = 0
        while True:
            localcnt += 1
            run_ops = [self.global_step, self.loss_op,self.ctr_loss, self.reg_loss,self.metrics,self.ctr_logits,self.localvar]
            try:
                if task_index == 0:
                    feed_dict = {'training:0': False}
                    # ctr_logits,ctr_labels = mon_session.run([self.ctr_logits,self.ctr_label],feed_dict=feed_dict)
                    # self.logger.info("ctr_logits:{},ctr_labels:{}".format(ctr_logits,ctr_labels))
                    global_step, loss,ctr_loss,reg_loss, metrics, ctr_logits,flocalv = mon_session.run(
                        run_ops, feed_dict=feed_dict)
                else:
                    feed_dict = {'training:0': True}
                    run_ops.append(self.train_ops)
                    global_step, loss,ctr_loss,reg_loss, metrics, ctr_logists,flocalv,_ = mon_session.run(
                        run_ops, feed_dict=feed_dict)

                if len(self.localvar) > 0:
                    index = np.array([0, -1])
                    self.logger.info(('localcnt:%s\t' % str(localcnt)) + '//'.join([x.name for x in self.localvar]))
                    self.logger.info(('localcnt:%s\t' % str(localcnt)) + '//'.join([str(x[index]) for x in flocalv]))

                ctr_auc, ctr_totalauc = metrics['scalar/ctr_auc'], metrics['scalar/ctr_total_auc']
                #cvr_auc, cvr_totalauc = metrics['scalar/cvr_auc'], metrics['scalar/cvr_total_auc']
                self.logger.info(
                    'Global_Step:{},loss={},ctr_loss={},ctr_auc={},ctr_total_auc={},reg_loss={},thread={}'.format(
                        str(global_step),
                        str(loss),
                        str(ctr_loss),
                        str(ctr_auc),
                        str(ctr_totalauc),
                        str(reg_loss),
                        str(thread_index)))
                newmark = np.max(flocalv[0][np.array([0, -1])])
                if newmark > 20000:
                    self.logger.info("positive_num now:{}".format(str(newmark)))
                    self.logger.info("auc_reset_step:{}".format(str(1000)))
                    self.logger.info('reset auc ops run')
                    index = np.array([0, -1])
                    flocalv = mon_session.run(self.reset_auc_ops, feed_dict=feed_dict)
                    self.logger.info(
                        ('localcnt:{}\t'.format(str(localcnt))) + '//'.join([x.name for x in self.localvar]))
                    self.logger.info(
                        ('localcnt:{}\t'.format(str(localcnt))) + '//'.join([str(x[index]) for x in flocalv]))

            except (ResourceExhaustedError, OutOfRangeError) as e:
                self.logger.info('Got exception run : %s | %s' % (e, traceback.format_exc()))
                break  # release all
            except ConnectionError as e:
                self.logger.info('Got exception run : %s | %s' % (e, traceback.format_exc()))
            except Exception as e:
                self.logger.info('Got exception run : %s | %s' % (e, traceback.format_exc()))

    def summary(self):
        with tf.name_scope("{}_Metrics".format(self.model_name)):
            self.logger.info('[summary] task_id={}'.format(self.context.get_task_id()))
            worker_device = "/job:worker/task:{}".format(self.context.get_task_id())
            with tf.device(worker_device):
                # ctr_auc
                self.ctr_current_auc, self.ctr_total_auc = auc(labels=self.ctr_label,
                                                       predictions=self.ctr_prediction,
                                                       num_thresholds=2000,
                                                       name=self.model_name + 'ctr-auc')
                decay_rate = self.algo_config.get('auc', {}).get('decay_rate', 0.999)
                ctr_current_auc_decay, ctr_update_auc_decay = metrics.auc(
                    labels=self.ctr_label,
                    predictions=self.ctr_prediction,
                    num_thresholds=2000,
                    name=self.model_name + '-decay_ctr_auc-' + str(decay_rate))
                with tf.control_dependencies([ctr_update_auc_decay]):
                    ctr_current_auc_decay = tf.identity(ctr_current_auc_decay)
                # fatigue_auc
                self.fatigue_current_auc, self.fatigue_total_auc = auc(labels=self.masked_fatigue_label,
                                                               predictions=self.masked_fatigue_prediction,
                                                               num_thresholds=2000,
                                                               name=self.model_name + 'fatigue-auc')
                decay_rate = self.algo_config.get('auc', {}).get('decay_rate', 0.999)
                fatigue_current_auc_decay, fatigue_update_auc_decay = metrics.auc(
                    labels=self.masked_fatigue_label,
                    predictions=self.masked_fatigue_prediction,
                    num_thresholds=2000,
                    name=self.model_name + '-decay_fatigue_auc-' + str(decay_rate))
                with tf.control_dependencies([fatigue_update_auc_decay]):
                    fatigue_current_auc_decay = tf.identity(fatigue_current_auc_decay)


        self.metrics['scalar/ctr_auc'] = self.ctr_current_auc
        self.metrics['scalar/ctr_total_auc'] = self.ctr_total_auc
        self.metrics['scalar/ctr_current_auc_decay'] = ctr_current_auc_decay
        self.metrics['scalar/fatigue_auc'] = self.fatigue_current_auc
        self.metrics['scalar/fatigue_total_auc'] = self.fatigue_total_auc
        self.metrics['scalar/fatigue_current_auc_decay'] = fatigue_current_auc_decay
        self.metrics['scalar/loss'] = self.loss_op
        self.metrics['scalar/alpha'] = tf.reduce_mean(self.alpha)
        self.metrics['scalar/ctr_loss'] = self.ctr_loss
        self.metrics['scalar/reg_loss'] = self.reg_loss
        self.metrics['scalar/fatigue_loss'] = self.fatigue_loss
        self.metrics['scalar/ctr_label_mean'] = tf.reduce_mean(self.ctr_label)
        self.metrics['scalar/ctr_logits_mean'] = tf.reduce_mean(self.ctr_logits)
        self.metrics['scalar/fatigue_label_mean'] = tf.reduce_mean(self.masked_fatigue_label)
        self.metrics['scalar/fatigue_logits_mean'] = tf.reduce_mean(self.fatigue_logits)
        self.metrics['scalar/ctr_logits_mean'] = tf.reduce_mean(self.ctr_logits)
        self.metrics['scalar/fatigue_predictions_mean'] = tf.reduce_mean(self.fatigue_prediction)
        with tf.name_scope("{}_Metrics_Scalar".format(self.model_name)):
            for key, metric in self.metrics.items():
                tf.summary.scalar(name=key, tensor=metric)
        self.context.get_model_ops().set_global_step(self.global_step)
        return self.metrics

    def input_layer(self,features,feature_columns):
        with self.variable_scope("{}_input_embedding_layer".format(self.model_name)) as input_scope:
                self.user_columns = feature_columns.get("user_columns",None)
                self.item_columns = feature_columns.get("item_columns",None)
                self.bias_columns = feature_columns.get("bias_columns",None)
                self.gate_columns = feature_columns.get("active_gate_columns",None)
                self.cate_fatigue_columns = feature_columns.get("cate_fatigue_columns",None)
                self.label_columns = feature_columns.get("label_columns",None)
                self.user_cate_pv_fatigue_columns = feature_columns.get("user_cate_pv_fatigue_columns", None)
                self.user_pv_fatigue_seq_length = feature_columns.get("user_pv_fatigue_seq_length",None)
                self.user_attention_columns = feature_columns.get("user_attention_columns", None)
                self.item_attention_columns = feature_columns.get("item_attention_columns", None)
                self.tb_item_attention_columns = feature_columns.get("target_item_columns",None)
                self.tb_brand_attention_columns = feature_columns.get("target_brand_columns", None)
                self.tb_cate_attention_columns = feature_columns.get("target_cate_columns", None)
                self.tb_seller_attention_columns = feature_columns.get("target_seller_columns", None)
                self.user_features = layers.input_from_feature_columns(
                            features,self.user_columns,scope=input_scope)
                self.item_features = layers.input_from_feature_columns(
                            features,self.item_columns,scope=input_scope)
                self.bias_features = layers.input_from_feature_columns(
                    features, self.bias_columns, scope=input_scope)
                self.gate_features = layers.input_from_feature_columns(
                    features, self.gate_columns, scope=input_scope)
                self.cate_fatigue_feature = layers.input_from_feature_columns(
                    features, self.cate_fatigue_columns,scope=input_scope)
                self.tb_item_attention_feature = layers.input_from_feature_columns(
                    features, self.tb_item_attention_columns, scope=input_scope)
                self.tb_brand_attention_feature = layers.input_from_feature_columns(
                    features, self.tb_brand_attention_columns, scope=input_scope)
                self.tb_cate_attention_feature = layers.input_from_feature_columns(
                    features, self.tb_cate_attention_columns, scope=input_scope)
                self.tb_seller_attention_feature = layers.input_from_feature_columns(
                    features, self.tb_seller_attention_columns, scope=input_scope)


                self.user_cate_pv_fatigue_features = layers.input_from_feature_columns(
                    features, self.user_cate_pv_fatigue_columns, scope=input_scope)
                self.user_attention_features = layers.input_from_feature_columns(features, self.user_attention_columns,
                                                                                 scope=input_scope)
                self.item_attention_features = layers.input_from_feature_columns(features, self.item_attention_columns,
                                                                                 scope=input_scope)
                print("user_cate_pv_fatigue_features shape:{}".format(
                    self.user_cate_pv_fatigue_features.get_shape().as_list()))

                ## seq_features ##
                # item_clk_seq
                self.user_clk_tm_seq_features, self.user_clk_tm_seq_length_features, self.user_clk_tm_seq_max_length = self.seq_featuer_maker(
                    features, feature_columns, self.fg,
                    "tm_clk_seq_list", "tm_clk_seq_len",
                    input_scope)
                # item_all_station_clk_seq
                self.user_all_clk_seq_features, self.user_all_clk_seq_length_features,self.user_all_clk_seq_max_length = self.seq_featuer_maker(
                    features, feature_columns, self.fg,
                    "all_clk_seq_list", "all_clk_seq_len",
                    input_scope)
                # brand_clk_seq
                self.user_tb_brand_clk_seq_features, self.user_tb_brand_clk_seq_length_features, self.user_tb_brand_clk_seq_max_length = self.seq_featuer_maker(
                    features, feature_columns, self.fg,
                    "ubp_seq_brand_list", "ubp_seq_brand_len_columns",
                    input_scope)
                # cate_clk_seq
                self.user_tb_cate_clk_seq_features, self.user_tb_cate_clk_seq_length_features, self.user_tb_cate_clk_seq_max_length = self.seq_featuer_maker(
                    features, feature_columns, self.fg,
                    "ubp_seq_cate_list", "ubp_seq_cate_len_columns",
                    input_scope)
                # seller_clk_seq
                self.user_tb_seller_clk_seq_features, self.user_tb_seller_clk_seq_length_features, self.user_tb_seller_clk_seq_max_length = self.seq_featuer_maker(
                    features, feature_columns, self.fg,
                    "ubp_seq_seller_list", "ubp_seq_seller_len_columns",
                    input_scope)

    def fusion_net(self,name,ctr_vector,fatigue_vector):
        with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
            with self.variable_scope("{}_ctr_output_net".format(name)) as var_scope:
                output = tf.concat([ctr_vector,fatigue_vector],axis=-1) # [b,128]
                output = layers.fully_connected(inputs=output, num_outputs=32, activation_fn=tf.nn.leaky_relu,
                                                scope="dim_{}".format(32),
                                                normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                normalizer_params={"scale": True, "is_training": self.is_training})
                if self.need_dropout:
                    output = tf.layers.dropout(output, rate=self.dropout_rate, training=self.is_training)
                ctr_logits = layers.linear(output, 1, scope="dim_1", biases_initializer=tf.constant_initializer(value=0))
            with self.variable_scope("{}_fatigue_output_net".format(name)) as var_scope:
                output = fatigue_vector
                output = layers.fully_connected(inputs=output, num_outputs=8, activation_fn=tf.nn.leaky_relu,
                                                scope="dim_{}".format(8),
                                                normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                normalizer_params={"scale": True, "is_training": self.is_training})
                if self.need_dropout:
                    output = tf.layers.dropout(output, rate=self.dropout_rate, training=self.is_training)
                fatigue_logits = layers.linear(output, 1, scope="dim_1",biases_initializer=tf.constant_initializer(value=0))
        return ctr_logits,fatigue_logits

    def UIN(self,name):
        with self.variable_scope("ctr_expert_{}".format(name)) as var_scope:
            _, tm_clk_item_atten = self.sequence_net("tm_clk",self.user_clk_tm_seq_max_length,
                                                                 self.user_clk_tm_seq_features,
                                                                 self.user_clk_tm_seq_length_features,
                                                                 None,
                                                                 self.item_attention_features)
            _, all_clk_item_atten = self.sequence_net("all_clk",self.user_all_clk_seq_max_length,
                                                                 self.user_all_clk_seq_features,
                                                                 self.user_all_clk_seq_length_features,
                                                                 None,
                                                                 self.item_attention_features)
            _, tb_clk_brandId_atten = self.sequence_net("tb_brand",self.user_tb_brand_clk_seq_max_length,
                                                                 self.user_tb_brand_clk_seq_features,
                                                                 self.user_tb_brand_clk_seq_length_features,
                                                                 None,
                                                                 self.tb_brand_attention_feature)
            _, tb_clk_cateId_atten = self.sequence_net("tb_cate", self.user_tb_cate_clk_seq_max_length,
                                                             self.user_tb_cate_clk_seq_features,
                                                             self.user_tb_cate_clk_seq_length_features,
                                                             None,
                                                             self.tb_cate_attention_feature)
            _, tb_clk_seller_atten = self.sequence_net("tb_seller", self.user_tb_seller_clk_seq_max_length,
                                                            self.user_tb_seller_clk_seq_features,
                                                            self.user_tb_seller_clk_seq_length_features,
                                                            None,
                                                            self.tb_seller_attention_feature)

            main_features = tf.concat([self.user_features, self.item_features,tm_clk_item_atten,
                                       all_clk_item_atten,tb_clk_brandId_atten,tb_clk_cateId_atten,tb_clk_seller_atten],axis=-1)
            ctr_vector = self.main_net(name,main_features) #[b,64]
            bias_vector = self.bias_net(name,self.bias_features) #[b,64]
            uin_vector = tf.concat([ctr_vector,bias_vector],axis=-1) #[b,32]
            return uin_vector #[b,96]

    def FRM(self,name,cate_fatigue_fft_seq,fatigue_feature,activate_gate_feature):
        with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
            with self.variable_scope("{}_fatigue_net".format(name)) as var_scope:
                F, F_real, F_imag = get_fft_transfer_matrix(32)
                freq_real,freq_imag, amplitude, phase = fft(cate_fatigue_fft_seq, F_real, F_imag, "cate_pv_neg_seq")
                W_phase = tf.get_variable(name="phase_weight",shape=[32,32],initializer=tf.random_normal_initializer(),trainable=True) # [32,32]

                fix_phase_weight = tf.nn.tanh(tf.matmul(phase,W_phase))  # [b,32]
                fft_out = tf.multiply(fix_phase_weight,amplitude) # [b,32]
                cate_weight,cate_bias = self.CMN(name,fatigue_feature) #[b,32]
                self.alpha = self.UCN(name,activate_gate_feature) #[b,1]
                fatigue_vector = self.alpha*(tf.multiply(fft_out,cate_weight)+cate_bias) #[b,32]
        return fatigue_vector

    def CMN(self,name,fatigue_feature):
        with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
            with self.variable_scope("{}_cate_weight_net".format(name)) as var_scope:
                weight = fatigue_feature
                for dim in self.faituage_net_hidden_dims:
                    weight = layers.fully_connected(inputs=weight, num_outputs=dim,
                                                    activation_fn=tf.nn.relu,
                                                    scope="dim_{}".format(dim),
                                                    normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                    normalizer_params={"scale": True, "is_training": self.is_training})
                    if self.need_dropout:
                        weight = tf.layers.dropout(weight, rate=self.dropout_rate, training=self.is_training)
            with self.variable_scope("{}_cate_bias_net".format(name)) as var_scope:
                bias = fatigue_feature
                for dim in self.faituage_net_hidden_dims:
                    bias = layers.fully_connected(inputs=bias, num_outputs=dim,
                                                    activation_fn=tf.nn.relu,
                                                    scope="dim_{}".format(dim),
                                                    normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                    normalizer_params={"scale": True, "is_training": self.is_training})
                    if self.need_dropout:
                        bias = tf.layers.dropout(bias, rate=self.dropout_rate, training=self.is_training)
            return weight,bias

    def main_net(self,name,features):
        with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
            with self.variable_scope("Expert_{}_net".format(name)) as main_net_scope:
                output = features
                for dim in self.ctr_expert_main_hidden_dims:
                    output = layers.fully_connected(inputs=output, num_outputs=dim, activation_fn=tf.nn.leaky_relu,
                                                    scope="dim_{}".format(dim),
                                                    normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                    normalizer_params={"scale": True, "is_training": self.is_training})
                    if self.need_dropout:
                        output = tf.layers.dropout(output, rate=self.dropout_rate, training=self.is_training)
        return output

    def bias_net(self,name,bias_features):
        with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
            with self.variable_scope("{}_bias_net".format(name)) as bias_net_scope:
                output = bias_features
                for dim in self.ctr_expert_bias_hidden_dims:
                    output = layers.fully_connected(inputs=output, num_outputs=dim, activation_fn=tf.nn.leaky_relu,
                                                    scope="dim_{}".format(dim),
                                                    normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                    normalizer_params={"scale": True,
                                                                       "is_training": self.is_training})
                    if self.need_dropout:
                        output = tf.layers.dropout(output, rate=self.dropout_rate, training=self.is_training)
                #logits_bias = layers.linear(output, 1, scope="dim_1", biases_initializer=None)
        return output #[b,32]

    def sequence_net(self,seq_name,max_len,sequence,sequence_length,user_atten_features,target_atten_features):
        with self.variable_scope("{}_{}_seq_layer".format(self.model_name,seq_name)) as scope:
            with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
                dec = []
                print(seq_name,"max_len:",max_len,"sequence shape:",sequence.get_shape().as_list(),"sequence_length shape:",sequence_length.get_shape().as_list())
                # max_len = self.user_clk_tm_seq_max_length
                # sequence = self.user_clk_tm_seq_features
                # sequence_length = self.user_clk_tm_seq_length_features
                sequence_mask = tf.sequence_mask(tf.reshape(sequence_length, [-1]), max_len)
                # '''
                #     self attention
                # '''
                # # vec shape: (batch, seq_len, dim)
                # self.logger.info('add self attention.')
                # with self.variable_scope("{}_self_atten_net".format(seq_name)) as atten_scope:
                #     vec, self_atten_weight = atten_func(query_masks=sequence_mask,
                #                                         key_masks=sequence_mask,
                #                                         queries=sequence,
                #                                         keys=sequence,
                #                                         values=sequence,
                #                                         num_units=self.model_conf['model_hyperparameter']['atten_param']['sa_num_units'],
                #                                         num_output_units=self.model_conf['model_hyperparameter']['atten_param']['sa_num_output_units'],
                #                                         scope=atten_scope,
                #                                         variables_collections=["{}_{}_self_atten_layer_variables".format(self.model_name,seq_name)],
                #                                         outputs_collections=["{}_{}_self_atten_layer_outputs".format(self.model_name,seq_name)],
                #                                         atten_mode=self.model_conf['model_hyperparameter']['atten_param']['atten_mode'],
                #                                         reuse=tf.AUTO_REUSE,
                #                                         num_heads=self.model_conf['model_hyperparameter']['atten_param']['num_heads'],
                #                                         residual_connection=self.model_conf['model_hyperparameter']['atten_param'].get('residual_connection', False),
                #                                         attention_normalize=self.model_conf['model_hyperparameter']['atten_param'].get('attention_normalize', False))
                    # self.debug_tensor_collector[block_name + 'self_attention'] = self_atten_weight
                if user_atten_features is None:
                    user_attent_u2i = None
                else:
                    with self.variable_scope("{}_user_atten_net".format(seq_name)) as user_atten_scope:
                        '''
                            user attention based self-attention
                        '''
                        # must be given user attention blocks or item attention blocks
                        self.logger.info('add user attention.')
                        # attention_layer = tf.concat(self.user_attention_features,axis=1)

                        user_atten_Q = tf.expand_dims(user_atten_features,1)

                        # sequence X user intent attention
                        # user_vec shape: (batch, 1, att_out)
                        user_vec, user_atten_weight = atten_func(queries=user_atten_Q,
                                                                     keys=sequence,
                                                                     values=sequence,
                                                                     key_masks=sequence_mask,
                                                                     query_masks=tf.sequence_mask(tf.ones_like(user_atten_Q[:, 0, 0],dtype=tf.int32), 1),
                                                                     num_units=self.model_conf['model_hyperparameter']['atten_param']['ma_num_units'],
                                                                     num_output_units=self.model_conf['model_hyperparameter']['atten_param']['ma_num_output_units'],
                                                                     scope=user_atten_scope,
                                                                     atten_mode=self.model_conf['model_hyperparameter']['atten_param']['atten_mode'],
                                                                     variables_collections=["{}_{}_user_atten_layer_variables".format(self.model_name,seq_name)],
                                                                     outputs_collections=["{}_{}_user_atten_layer_outputs".format(self.model_name,seq_name)],
                                                                     reuse=tf.AUTO_REUSE,
                                                                     num_heads=self.model_conf['model_hyperparameter']['atten_param']['num_heads'],
                                                                     residual_connection=self.model_conf['model_hyperparameter']['atten_param'].get('residual_connection',False),
                                                                     attention_normalize=self.model_conf['model_hyperparameter']['atten_param'].get('attention_normalize',False))

                        if self.model_conf['model_hyperparameter']['atten_param'].get('residual_connection', False):
                            ma_num_output_units = user_atten_Q.get_shape().as_list()[-1]
                        else:
                            ma_num_output_units = self.model_conf['model_hyperparameter']['atten_param']['ma_num_output_units']
                        user_attent_u2i = tf.reshape(user_vec, [-1, ma_num_output_units])
                        dec.append(tf.reshape(user_vec, [-1, ma_num_output_units]))
                        # self.debug_tensor_collector[block_name + 'user_attention'] = user_atten_weight
                with self.variable_scope("{}_target_atten_net".format(seq_name)) as target_atten_scope:
                    '''
                        target attention based self-attention
                    '''
                    self.logger.info('add target attention.')
                    #attention_layer = tf.concat(self.item_attention_features,axis=1)
                    target_atten_Q = tf.expand_dims(target_atten_features, 1)

                    # sequence X target attention
                    # item_vec shape: (batch, seq_len, att_out)
                    item_vec, item_atten_weight = atten_func(queries=target_atten_Q,
                                                                 keys=sequence,
                                                                 values=sequence,
                                                                 key_masks=sequence_mask,
                                                                 query_masks=tf.sequence_mask(tf.ones_like(target_atten_Q[:, 0, 0],dtype=tf.int32), 1),
                                                                 num_units=self.model_conf['model_hyperparameter']['atten_param']['ma_num_units'],
                                                                 num_output_units=self.model_conf['model_hyperparameter']['atten_param']['ma_num_output_units'],
                                                                 scope=target_atten_scope,
                                                                 atten_mode=self.model_conf['model_hyperparameter']['atten_param']['atten_mode'],
                                                                 variables_collections=["{}_{}_target_atten_layer_variable".format(self.model_name,seq_name)],
                                                                 outputs_collections=["{}_{}_target_atten_layer_outputs".format(self.model_name,seq_name)],
                                                                 reuse=tf.AUTO_REUSE,
                                                                 num_heads=self.model_conf['model_hyperparameter']['atten_param']['num_heads'],
                                                                 residual_connection=self.model_conf['model_hyperparameter']['atten_param'].get('residual_connection',False),
                                                                 attention_normalize=self.model_conf['model_hyperparameter']['atten_param'].get('attention_normalize',False))

                    if self.model_conf['model_hyperparameter']['atten_param'].get('residual_connection', False):
                        ma_num_output_units = target_atten_Q.get_shape().as_list()[-1]
                    else:
                        ma_num_output_units = self.model_conf['model_hyperparameter']['atten_param']['ma_num_output_units']
                    target_atten_i2i = tf.reshape(item_vec, [-1, ma_num_output_units])
                    dec.append(tf.reshape(item_vec, [-1, ma_num_output_units]))
                # return tf.concat(dec,axis=1)
                return user_attent_u2i,target_atten_i2i
                        # self.debug_tensor_collector[block_name + 'item_attention'] = item_atten_weight
                    #self.layer_dict[block_name] = tf.concat(dec, axis=1

    def UCN(self,name,gate_features):
        with self.variable_scope("{}_user_activate_gate_net".format(name)) as gate_scope:
            with arg_scope(model_arg_scope(weight_decay=self.model_conf["model_hyperparameter"]["regularizer_weight_l2"])):
                output= gate_features
                for dim in self.gate_hidden_dims:
                    output=layers.fully_connected(output,
                                                dim,
                                                activation_fn=tf.nn.leaky_relu,
                                                normalizer_fn=layers.batch_norm if self.need_batchnorm else None,
                                                normalizer_params={"scale": True, "is_training": self.is_training},
                                                scope="gate_net_{}".format(dim))
                alpha = layers.fully_connected(output,
                                                1,
                                                activation_fn=tf.nn.sigmoid,
                                                scope="gate_net_1")
        return alpha

    def optimizer(self, context, loss_op):
        with tf.variable_scope(name_or_scope="{}_Optimize".format(self.model_name),partitioner=self.variable_partitioner,reuse=tf.AUTO_REUSE):
            optimizer_dict = {
                "AdagradDecay": lambda opt_conf, global_step: SearchAdagradDecay(opt_conf).get_optimizer(global_step),
                "Adagrad": lambda opt_conf, global_step: SearchAdagrad(opt_conf).get_optimizer(global_step),
                "GradientDecent": lambda opt_conf, global_step: SearchGradientDecent(opt_conf).get_optimizer(global_step)
            }
            global_opt_name = self.opts_conf["select_opt"]
            global_opt_conf = self.opts_conf[global_opt_name]
            global_optimizer = optimizer_dict[global_opt_name](global_opt_conf,self.global_step)
            global_opt_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, scope=None)
            if len(global_opt_vars) == 0:
                raise ValueError("no trainable variables")

            #update_ops = self.update_op(name=self.model_name)
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)

            train_ops = []
            train_op, self.out_gradient_norm, self.out_var_norm = myopt.optimize_loss(
                loss=loss_op,
                global_step=self.global_step,
                learning_rate=self.opts_conf[global_opt_name].get("learning_rate", 0.01),
                optimizer=global_optimizer,
                # update_ops=update_ops,
                clip_gradients=self.opts_conf[global_opt_name].get('clip_gradients', 5.0),
                variables=global_opt_vars,
                increment_global_step=False,
                summaries=myopt.OPTIMIZER_SUMMARIES,
            )
            train_ops.append(train_op)

            with tf.control_dependencies(update_ops):
                train_op_vec = control_flow_ops.group(*train_ops)
                with ops.control_dependencies([train_op_vec]):
                    with ops.colocate_with(self.global_step):
                        self.train_ops = state_ops.assign_add(self.global_step, 1).op
                        return self.train_ops

    def set_global_step(self):
        """Sets up the global step Tensor."""
        self.global_step = training_util.get_or_create_global_step()
        self.global_step_reset = tf.assign(self.global_step, 0)
        self.global_step_add = tf.assign_add(self.global_step, 1, use_locking=True)
        tf.summary.scalar('global_step/' + self.global_step.name, self.global_step)
        return self.global_step

    def mark_output(self, prediction,fatigue_prediction):
        with tf.name_scope("%s_Mark_Output" % "CTR"):
            logistic = tf.identity(prediction, name="rank_predict")
        with tf.name_scope("%s_Mark_Output" % "Fatigue"):
            fatigue = tf.identity(fatigue_prediction, name="rank_predict")

    def add_worker_summary_hook(self, context):
        config = context.get_config()
        self.logger.info('[add_worker_summary_hook] config={}'.format(config))
        if config.get_job_config('worker_tensorboard_hook') == True \
                or config.get_job_config('worker_tensorboard_hook') is None:
            self.logger.info('worker_tensorboard_hook switch on')
            ckpt_base = config.get_job_config("cluster")["ckpt_dir"]
            ckpt_path = "{}/train/".format(ckpt_base)
            ckpt_eval_path = "{}/eval/".format(ckpt_base)
            self.logger.info("ckpt path is : {}".format(ckpt_path))
            self.logger.info("ckpt eval path is : {}".format(ckpt_eval_path))
            h = tf.train.SummarySaverHook(save_steps=100, output_dir=ckpt_path, summary_op=tf.summary.merge_all())
            eval_h = tf.train.SummarySaverHook(save_steps=100, output_dir=ckpt_eval_path,
                                               summary_op=tf.summary.merge_all())

            eval_worker_num = config.get_job_config('eval_worker_num')
            if eval_worker_num is None or not isinstance(eval_worker_num, int):
                eval_worker_num = 1
            if context.get_task_id() <= eval_worker_num and context.get_task_id() > 0:
                self.logger.info("add the summary saver hooker for worker: {}".format(context.get_task_id()))
                context.add_hook(h)
            elif context.get_task_id() == 0:
                self.logger.info("add the eval summary saver hooker for worker: {}".format(context.get_task_id()))
                context.add_hook(eval_h)

    def add_sample_trace_dict(self, key, value):
        try:
            self.sample_trace_dict[key] = tf.sparse_tensor_to_dense(value, default_value="")
        except:
            self.sample_trace_dict[key] = value

    def set_reset_op(self, collection_key=tf.GraphKeys.LOCAL_VARIABLES, matchname='auc/', not_match=None):
        localv = tf.get_collection(collection_key)
        localv = [x for x in localv if matchname in x.name]
        if not_match is not None:
            localv = [x for x in localv if not_match not in x.name]
        retvops = [tf.assign(x, array_ops.zeros(shape=x.get_shape(), dtype=x.dtype)) for x in localv]
        if len(retvops) == 0:
            return None, None
        retvops = tf.tuple(retvops)
        return retvops, localv

    def predictions(self,ctr_logits,fatigue_logits):
        with tf.name_scope("Predictions"):
           ctr_prediction= tf.nn.sigmoid(ctr_logits)
           fatigue_prediction = tf.nn.sigmoid(fatigue_logits)
        return ctr_prediction,fatigue_prediction #[b*l,]

    def variable_scope(self,name,reuse=tf.AUTO_REUSE):
        variable_partitioner = partitioned_variables.min_max_variable_partitioner(
            max_partitions=self.config.get_job_config("ps_num"),
            min_slice_size=self.config.get_job_config("embedding_min_slice_size"))
        variable_scope=tf.variable_scope(name_or_scope=name, partitioner=variable_partitioner,reuse=reuse)
        return variable_scope

    def seq_featuer_maker(self,features, feature_columns, fg, seq_name, seq_length_name, scope):
        seq_columns = feature_columns.get(seq_name, None)
        seq_max_length = fg.get_seq_len_by_sequence_name(seq_name)
        seq_features = layers.input_from_feature_columns(features, seq_columns,
                                                         scope=scope)  # [bs*seq_len, dim] bs个样本的内的第1个序列元素，bs个样本的内的第2个序列元素，。。。。
        seq_sequence_split = tf.split(seq_features, seq_max_length,
                                      axis=0)  # [ [bs, dim] ] list 形式，list size = seq_len 不是tensor,list内第n个元素表示bs个序列第n个元素embedding
        seq_sequence_stack = tf.stack(values=seq_sequence_split, axis=1)  # [batch,seq_len,dim]
        seq_feature_2d = tf.reshape(seq_sequence_stack, [-1, tf.shape(seq_sequence_stack)[2]])  # [bs*len,dim]

        seq_length_columns = feature_columns.get(seq_length_name, None)
        seq_length_features = layers.input_from_feature_columns(features, seq_length_columns, scope=scope)  # [bs,1]
        sequence_mask = tf.sequence_mask(tf.reshape(seq_length_features, [-1]),
                                         seq_max_length)  # [bs,seq_max_len],bool 根据长度来生产mask的sequence
        masked_seq_features = tf.reshape(
            tf.where(tf.reshape(sequence_mask, [-1]), seq_feature_2d, tf.zeros_like(seq_feature_2d)),
            tf.shape(seq_sequence_stack))  # [batch,seq_len,dim]
        return masked_seq_features, seq_length_features, seq_max_length




